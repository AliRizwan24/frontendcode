import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';

const AddItemPage = () => {
  const [form, setForm] = useState({ name: '', description: '' });
  const navigate = useNavigate();

  const handleChange = e => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const handleSubmit = async e => {
    e.preventDefault();
    await axios.post('http://localhost:5000/api/items', form);
    navigate('/items');
  };

  return (
    <form onSubmit={handleSubmit} className="p-4 max-w-xl mx-auto">
      <h1 className="text-2xl mb-4">Add New Item</h1>
      <input name="name" placeholder="Name" onChange={handleChange} required className="block w-full border p-2 mb-2" />
      <textarea name="description" placeholder="Description" onChange={handleChange} required className="block w-full border p-2 mb-2" />
      <button type="submit" className="bg-blue-500 text-white px-4 py-2 rounded">Add</button>
    </form>
  );
};

export default AddItemPage;