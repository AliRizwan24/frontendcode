import { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import axios from 'axios';

const ItemDetailsPage = () => {
  const { id } = useParams();
  const [item, setItem] = useState(null);

  useEffect(() => {
    axios.get(`http://localhost:5000/api/items/${id}`)
      .then(res => setItem(res.data))
      .catch(err => console.error(err));
  }, [id]);

  if (!item) return <div>Loading...</div>;

  return (
    <div className="p-4">
      <h1 className="text-2xl mb-4">Item Details</h1>
      <div className="border p-4 rounded shadow max-w-xl mx-auto">
        <h2 className="text-xl font-semibold">{item.name}</h2>
        <p className="mt-2">{item.description}</p>
        <p className="text-gray-500 mt-4">Created At: {new Date(item.createdAt).toLocaleString()}</p>
        <Link to="/items" className="inline-block mt-4 bg-blue-500 text-white px-4 py-2 rounded">Back</Link>
      </div>
    </div>
  );
};

export default ItemDetailsPage;