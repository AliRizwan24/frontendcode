import { useState, useEffect } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import axios from 'axios';

const EditItemPage = () => {
  const { id } = useParams();
  const [form, setForm] = useState({ name: '', description: '' });
  const navigate = useNavigate();

  useEffect(() => {
    axios.get(`http://localhost:5000/api/items/${id}`)
      .then(res => setForm(res.data))
      .catch(err => console.error(err));
  }, [id]);

  const handleChange = e => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const handleSubmit = async e => {
    e.preventDefault();
    await axios.put(`http://localhost:5000/api/items/${id}`, form);
    navigate('/items');
  };

  return (
    <form onSubmit={handleSubmit} className="p-4 max-w-xl mx-auto">
      <h1 className="text-2xl mb-4">Edit Item</h1>
      <input name="name" value={form.name} onChange={handleChange} required className="block w-full border p-2 mb-2" />
      <textarea name="description" value={form.description} onChange={handleChange} required className="block w-full border p-2 mb-2" />
      <button type="submit" className="bg-yellow-500 text-white px-4 py-2 rounded">Update</button>
    </form>
  );
};

export default EditItemPage;