import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import axios from 'axios';

const ViewItemsPage = () => {
  const [items, setItems] = useState([]);

  useEffect(() => {
    axios.get('http://localhost:5000/api/items')
      .then(res => setItems(res.data))
      .catch(err => console.error(err));
  }, []);

  const handleDelete = (id) => {
    axios.delete(`http://localhost:5000/api/items/${id}`)
      .then(() => setItems(items.filter(item => item._id !== id)))
      .catch(err => console.error(err));
  };

  return (
    <div className="p-4">
      <h1 className="text-2xl mb-4">Items</h1>
      <Link to="/add-item" className="bg-blue-500 text-white px-4 py-2 rounded">Add New Item</Link>
      <div className="mt-4 space-y-4">
        {items.map(item => (
          <div key={item._id} className="border p-4 rounded shadow">
            <h2 className="text-xl">{item.name}</h2>
            <p>{item.description}</p>
            <div className="space-x-2 mt-2">
              <Link to={`/items/${item._id}`} className="bg-green-500 px-2 py-1 text-white rounded">View</Link>
              <Link to={`/edit-item/${item._id}`} className="bg-yellow-500 px-2 py-1 text-white rounded">Edit</Link>
              <button onClick={() => handleDelete(item._id)} className="bg-red-500 px-2 py-1 text-white rounded">Delete</button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default ViewItemsPage;