const Footer = () => (
  <footer className="bg-gray-800 text-white text-center p-4 mt-4">
    <p>&copy; 2025 CRUD App. All rights reserved.</p>
  </footer>
);

export default Footer;