import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Navbar from './components/Navbar';
import Footer from './components/Footer';
import HomePage from './pages/HomePage';
import ViewItemsPage from './pages/ViewItemsPage';
import ItemDetailsPage from './pages/ItemDetailsPage';
import AddItemPage from './pages/AddItemPage';
import EditItemPage from './pages/EditItemPage';

const App = () => {
  return (
    <Router>
      <div className="min-h-screen flex flex-col">
        <Navbar />
        <main className="flex-grow p-4">
          <Routes>
            <Route path="/" element={<HomePage />} />
            <Route path="/items" element={<ViewItemsPage />} />
            <Route path="/items/:id" element={<ItemDetailsPage />} />
            <Route path="/add-item" element={<AddItemPage />} />
            <Route path="/edit-item/:id" element={<EditItemPage />} />
          </Routes>
        </main>
        <Footer />
      </div>
    </Router>
  );
};

export default App;